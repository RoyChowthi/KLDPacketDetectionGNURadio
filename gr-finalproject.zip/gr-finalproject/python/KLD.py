from gnuradio import gr
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal,misc
from scipy import stats
import statistics
import pmt

class KLD(gr.sync_block):
    """
    docstring for block KLDivergence
    """
    def __init__(self):
        gr.sync_block.__init__(self,
            name="KLD",
            in_sig=[np.complex64],
            out_sig=[np.float32])

    
    def work(self, input_items, output_items):

        def cross_entropy(X, Y):
            return sum(X * np.log2(X / Y)) 


        in0 = input_items[0]
        out = output_items[0]
        onemilsamps = in0

        x = np.real(onemilsamps)
        y = np.imag(onemilsamps)
        amp = np.sqrt(x**2 + y**2)
        out[:] = amp
        sample_size = 205 # number of IQ or AMP values per sample
        set_size = int(len(onemilsamps)/sample_size) # number of samples per bin
        
        seq_a = np.zeros((set_size,sample_size),dtype=np.float32)
        for i in range (0, set_size):
            j = i +1
            sub = amp[i*sample_size: j*sample_size]
            seq_a[i,:] = np.array(sub)

        kl_set = np.zeros((set_size-1,1))

        for i in range (0,set_size-1):
            kl_set[i] = cross_entropy(seq_a[i], seq_a[i + 1]) - cross_entropy(seq_a[i], seq_a[i])
            kl_val = kl_set[i]

        for i in range (0,set_size-1):
            kl_vals = kl_set[i]
            if (kl_vals <= 0.6):
                key = pmt.intern("packet boundary")
                value = pmt.intern(str(i))
                self.add_item_tag(0,self.nitems_written(0)+i, key, value)
        
        return len(output_items[0])       

